// ----------------------
// FS CONFIG

int detikiqmh;
int menitiqmh;

uint8_t iqmhs = 1; // menit
uint8_t iqmhd = 1; // menit
uint8_t iqmha = 1; // menit
uint8_t iqmhm = 1; // menit
uint8_t iqmhi = 1; // menit

uint8_t durasiadzan = 1; // Menit
uint8_t tipealarm;

uint8_t tmputama;
uint8_t tmpjws;
uint8_t tmpinfo;
