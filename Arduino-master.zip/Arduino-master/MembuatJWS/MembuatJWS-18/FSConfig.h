


int detikiqmh;
int menitiqmh;

uint8_t tmputama;
uint8_t tmpjws;
uint8_t tmpinfo;
